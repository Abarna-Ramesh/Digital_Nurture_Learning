import './App.css';
import Posts from './components/Posts';

function App() {
  return (
    <div>
      <h1>Welcome</h1>
      <Posts />
    </div>
  );
}

export default App;
